document.addEventListener('DOMContentLoaded', function() {
    const features = document.querySelectorAll('.feature-box');
  
    window.addEventListener('scroll', function() {
      features.forEach(feature => {
        const position = feature.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
  
        if (position < windowHeight - 100) {
          feature.style.animation = 'slideUp 1s ease-out forwards';
        }
      });
    });
  });
  
  /* CSS animation for slide up
  